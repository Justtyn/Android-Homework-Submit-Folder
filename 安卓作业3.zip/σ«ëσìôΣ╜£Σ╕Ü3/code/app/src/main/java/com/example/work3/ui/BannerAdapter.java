package com.example.work3.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.work3.R;

public class BannerAdapter extends RecyclerView.Adapter<BannerAdapter.BannerViewHolder> {
    
    private final int[] bannerImages = {
        R.drawable.banner_1,
        R.drawable.banner_2,
        R.drawable.banner_3
    };
    
    private final String[] bannerTitles = {
        "精选表情包",
        "热门推荐",
        "最新上架"
    };
    
    @NonNull
    @Override
    public BannerViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_banner_slide, parent, false);
        return new BannerViewHolder(view);
    }
    
    @Override
    public void onBindViewHolder(@NonNull BannerViewHolder holder, int position) {
        holder.imageView.setImageResource(bannerImages[position]);
        holder.textView.setText(bannerTitles[position]);
    }
    
    @Override
    public int getItemCount() {
        return bannerImages.length;
    }
    
    static class BannerViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textView;
        
        BannerViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imgBanner);
            textView = itemView.findViewById(R.id.tvBannerTitle);
        }
    }
}
