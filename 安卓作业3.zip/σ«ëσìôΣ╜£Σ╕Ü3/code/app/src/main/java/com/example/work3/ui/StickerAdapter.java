package com.example.work3.ui;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.example.work3.R;
import com.example.work3.data.StickerItem;

import java.util.ArrayList;
import java.util.List;

public class StickerAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public static final int TYPE_HEADER = 0;
    public static final int TYPE_SECTION = 1;
    public static final int TYPE_ITEM = 2;

    private final List<Object> data = new ArrayList<>();

    public void submit(List<StickerItem> items) {
        data.clear();
        data.add("HEADER");
        data.add("更多精选");
        data.addAll(items);
        notifyDataSetChanged();
    }

    @Override
    public int getItemViewType(int position) {
        Object obj = data.get(position);
        if (obj instanceof String) {
            return "HEADER".equals(obj) ? TYPE_HEADER : TYPE_SECTION;
        }
        return TYPE_ITEM;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inf = LayoutInflater.from(parent.getContext());
        if (viewType == TYPE_HEADER) {
            View v = inf.inflate(R.layout.item_header_banner, parent, false);
            return new HeaderVH(v);
        } else if (viewType == TYPE_SECTION) {
            View v = inf.inflate(R.layout.item_section_title, parent, false);
            return new SectionVH(v);
        } else {
            View v = inf.inflate(R.layout.item_sticker_row, parent, false);
            return new ItemVH(v);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder h, int position) {
        int type = getItemViewType(position);
        if (type == TYPE_SECTION) {
            ((SectionVH) h).tv.setText(String.valueOf(data.get(position)));
        } else if (type == TYPE_ITEM) {
            StickerItem item = (StickerItem) data.get(position);
            ItemVH vh = (ItemVH) h;
            vh.icon.setImageResource(item.getIconRes());
            vh.title.setText(item.getTitle());
        }
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class HeaderVH extends RecyclerView.ViewHolder {
        ViewPager2 viewPager;
        LinearLayout indicatorContainer;
        BannerAdapter bannerAdapter;
        
        HeaderVH(@NonNull View itemView) {
            super(itemView);
            viewPager = itemView.findViewById(R.id.viewPagerBanner);
            indicatorContainer = itemView.findViewById(R.id.indicatorContainer);
            
            // 设置ViewPager2
            bannerAdapter = new BannerAdapter();
            viewPager.setAdapter(bannerAdapter);
            
            // 设置指示器
            setupIndicators();
            
            // 监听页面变化更新指示器
            viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageSelected(int position) {
                    updateIndicators(position);
                }
            });
        }
        
        private void setupIndicators() {
            indicatorContainer.removeAllViews();
            for (int i = 0; i < 3; i++) {
                ImageView indicator = new ImageView(itemView.getContext());
                indicator.setImageResource(R.drawable.indicator_unselected);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                );
                params.setMargins(4, 0, 4, 0);
                indicator.setLayoutParams(params);
                indicatorContainer.addView(indicator);
            }
            updateIndicators(0);
        }
        
        private void updateIndicators(int position) {
            for (int i = 0; i < indicatorContainer.getChildCount(); i++) {
                ImageView indicator = (ImageView) indicatorContainer.getChildAt(i);
                indicator.setImageResource(i == position ? R.drawable.indicator_selected : R.drawable.indicator_unselected);
            }
        }
    }

    static class SectionVH extends RecyclerView.ViewHolder {
        TextView tv;

        SectionVH(@NonNull View itemView) {
            super(itemView);
            tv = itemView.findViewById(R.id.tvSection);
        }
    }

    static class ItemVH extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView title, btnAdd;

        ItemVH(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.imgIcon);
            title = itemView.findViewById(R.id.tvTitle);
            btnAdd = itemView.findViewById(R.id.btnAdd);
        }
    }
}
