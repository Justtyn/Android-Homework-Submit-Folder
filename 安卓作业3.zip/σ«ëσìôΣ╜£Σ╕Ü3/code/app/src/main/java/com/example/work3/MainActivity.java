package com.example.work3;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.work3.data.StickerItem;
import com.example.work3.ui.SpaceItemDecoration;
import com.example.work3.ui.StickerAdapter;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.tabs.TabLayout;

import java.util.Arrays;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar bar = findViewById(R.id.topAppBar);
        setSupportActionBar(bar);

        TabLayout tabs = findViewById(R.id.tabLayout);
        tabs.addTab(tabs.newTab().setText("精选表情"));
        tabs.addTab(tabs.newTab().setText("更多表情"));

        RecyclerView rv = findViewById(R.id.rvSticker);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setItemAnimator(null);
        rv.addItemDecoration(new SpaceItemDecoration(dp(8)));

        StickerAdapter adapter = new StickerAdapter();
        rv.setAdapter(adapter);

        // 固定数据（可自行替换资源与标题）
        List<StickerItem> list = Arrays.asList(
                new StickerItem(R.drawable.ic_cat1, "鱼烧哥第十一弹"),
                new StickerItem(R.drawable.ic_doge1, "布丁无语第四套"),
                new StickerItem(R.drawable.ic_cat1, "猫脸mer"),
                new StickerItem(R.drawable.ic_doge1, "比格多栋"),
                new StickerItem(R.drawable.ic_angry_eggplant, "愤怒的茄子"),
                new StickerItem(R.drawable.ic_monkey, "职场马猴"),
                new StickerItem(R.drawable.ic_cat1, "阿莫是橘猫")
        );
        adapter.submit(list);
    }

    private int dp(int v) {
        float d = getResources().getDisplayMetrics().density;
        return (int) (v * d + 0.5f);
    }
}