package com.example.work4;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.AlphaAnimation;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        

        ImageView splashImage = findViewById(R.id.splash_image);

        // 1. 渐显动画（1.5 秒）
        AlphaAnimation fadeIn = new AlphaAnimation(0f, 1f);
        fadeIn.setDuration(1500);
        fadeIn.setFillAfter(true);
        splashImage.startAnimation(fadeIn);

        // 2. 延时 3 秒后执行淡出 + 跳转
        new Handler().postDelayed(() -> {
            AlphaAnimation fadeOut = new AlphaAnimation(1f, 0f);
            fadeOut.setDuration(1200);
            fadeOut.setFillAfter(true);
            splashImage.startAnimation(fadeOut);

            // 动画结束后跳转主界面
            splashImage.postDelayed(() -> {
                Intent intent = new Intent(SplashActivity.this, MainActivity.class);
                startActivity(intent);
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
                finish();
            }, 1200);
        }, 3000); // 显示时间 3 秒
    }
}
