package com.example.work4;
import com.example.work4.R;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private WeixinFragment weixinFragment;
    private ContactFragment contactFragment;
    private DiscoverFragment discoverFragment;
    private ProfileFragment profileFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottom_navigation);

        // 初始化四个 Fragment
        weixinFragment = new WeixinFragment();
        contactFragment = new ContactFragment();
        discoverFragment = new DiscoverFragment();
        profileFragment = new ProfileFragment();

        // 默认显示微信页面
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.nav_host_fragment, weixinFragment)
                .commit();

        // 底部导航监听
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int id = item.getItemId();
            Fragment selectedFragment = null;

            if (id == R.id.nav_weixin) {
                selectedFragment = weixinFragment;
            } else if (id == R.id.nav_contact) {
                selectedFragment = contactFragment;
            } else if (id == R.id.nav_discover) {
                selectedFragment = discoverFragment;
            } else if (id == R.id.nav_profile) {
                selectedFragment = profileFragment;
            }

            if (selectedFragment != null) {
                getSupportFragmentManager().beginTransaction()
                        .replace(R.id.nav_host_fragment, selectedFragment)
                        .commit();
            }
            return true;
        });

    }
}
