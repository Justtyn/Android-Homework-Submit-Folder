package com.example.work4;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;
import java.util.List;

public class EmojiStoreActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private List<Integer> bannerImages;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emoji_store);

        // 返回按钮
        TextView backButton = findViewById(R.id.back_button);

        // 点击返回按钮返回上一个页面
        backButton.setOnClickListener(v -> {
            finish(); // 关闭当前Activity，返回上一个
        });

        // 轮播图初始化
        viewPager = findViewById(R.id.viewPager);
        bannerImages = new ArrayList<>();
        bannerImages.add(R.drawable.banner1);
        bannerImages.add(R.drawable.banner2);
        bannerImages.add(R.drawable.banner3);

        EmojiBannerAdapter adapter = new EmojiBannerAdapter(this, bannerImages);
        viewPager.setAdapter(adapter);
    }
}
