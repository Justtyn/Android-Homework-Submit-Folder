package com.example.work4;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;

public class ProfileFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        ImageView avatar = view.findViewById(R.id.avatar);
        LinearLayout ll = view.findViewById(R.id.ll);

        ll.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), UserinfoActivity.class);
            startActivity(intent);
        });

        avatar.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), UserinfoActivity.class);
            startActivity(intent);
        });

        LinearLayout emojiLayout = view.findViewById(R.id.emoji_tv);
        emojiLayout.setOnClickListener(v -> {
            Intent intent = new Intent(getActivity(), EmojiStoreActivity.class);
            startActivity(intent);
        });


        return view;
    }
}
