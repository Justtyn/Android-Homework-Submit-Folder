package com.example.work4;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class UserinfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);

        // 获取返回按钮
        TextView backButton = findViewById(R.id.back_button);

        // 点击返回按钮返回上一个页面
        backButton.setOnClickListener(v -> {
            finish(); // 关闭当前Activity，返回上一个
        });
    }
}
